from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy


db = SQLAlchemy()
migrate = Migrate()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'thisissecretkey'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////Users/rosa/Desktop/prototype_f/dbs/useradmini.db'

    db.init_app(app)

    return app