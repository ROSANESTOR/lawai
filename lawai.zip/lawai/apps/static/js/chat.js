document.addEventListener('DOMContentLoaded', function() {
    var socket = io.connect(location.protocol + '//' + document.domain + ':' + location.port);
    var form = document.getElementById('chat-form');

    socket.on('connect', function() {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            var message = document.getElementById('msg').value;
            socket.emit('message', {'msg': message, 'room': '{{ room.id }}'});
            document.getElementById('msg').value = '';
        });
    });

    socket.on('message', function(data) {
        var chatBox = document.getElementById('chat-box');
        var msgDiv = document.createElement('div');
        msgDiv.classList.add('chat-message');
        msgDiv.innerHTML = `<strong>${data.username}:</strong> ${data.msg}`;
        chatBox.appendChild(msgDiv);
        chatBox.scrollTop = chatBox.scrollHeight;
    });
});
