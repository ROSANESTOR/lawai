from flask import Flask, render_template, request, redirect, session, url_for, flash
from transformers import AutoTokenizer, AutoModelForCausalLM
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_cors import CORS
from flask_wtf.csrf import CSRFProtect
from flask_migrate import Migrate
import sqlite3
from datetime import datetime
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_bcrypt import Bcrypt
import re

app = Flask(__name__, template_folder='/Users/rosa/Desktop/lawai/templates')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////Users/rosa/Desktop/lawai/dbs/useradmini.db'
app.config['SQLALCHEMY_BINDS'] = {
    'after': 'sqlite:////Users/rosa/Desktop/lawai/dbs/after.db'
}
app.config['SECRET_KEY'] = 'thisissecretkey'
db = SQLAlchemy(app)
migrate = Migrate(app, db)
CORS(app)
csrf = CSRFProtect(app)
socketio = SocketIO(app)
bcrypt = Bcrypt(app)

model_name = "EleutherAI/polyglot-ko-1.3b"
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(model_name)

def generate_response(prompt, max_new_tokens=50):
    formatted_prompt = f"User: {prompt}\nAI:"
    inputs = tokenizer(formatted_prompt, return_tensors="pt")
    output = model.generate(
        **inputs,
        max_new_tokens=max_new_tokens,
        num_return_sequences=1,
        pad_token_id=tokenizer.eos_token_id
    )
    response = tokenizer.decode(output[0], skip_special_tokens=True)
    return response.strip().replace(formatted_prompt, "").strip()

class data(db.Model):
    __bind_key__ = 'after'
    time = db.Column(db.DateTime)
    id = db.Column(db.Integer)
    name = db.Column(db.String, primary_key=True)
    log = db.Column(db.String)
    def __repr__(self):
        return f"<data(time='{self.time}', id={self.id}, name='{self.name}', log='{self.log}')>"

class User(db.Model):
    id = db.Column(db.String(15), primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    age = db.Column(db.Integer)
    student_number = db.Column(db.Integer)
    level = db.Column(db.Integer, default=2)
    password_hash = db.Column(db.String(100), nullable=False)
    ai_chat_room = db.relationship('AIChatRoom', uselist=False, backref='user')

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

    articles = db.relationship('Article', backref='author', lazy=True)

class Board(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)

class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    board_id = db.Column(db.Integer, db.ForeignKey('board.id'), nullable=False)
    title = db.Column(db.String(100), nullable=False)
    content = db.Column(db.Text, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class ChatRoom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)

class ChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    room_id = db.Column(db.Integer, db.ForeignKey('chat_room.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class AIChatRoom(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    messages = db.relationship('AIChatMessage', backref='chat_room', lazy=True)

class AIChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    chat_room_id = db.Column(db.Integer, db.ForeignKey('ai_chat_room.id'), nullable=False)
    sender = db.Column(db.String(10), nullable=False)
    message = db.Column(db.String(500), nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

with app.app_context():
    db.create_all()

@app.route("/newsletter")
def newsletter():
    return render_template('준비중.html')

@app.route("/about")
def about():
    return render_template('about.html')

@app.route("/board_cre")
def board_cre():
    return render_template('create_board.html')

@app.route("/redirect")
def redirect_to_previous():
    referrer = request.referrer
    if referrer:
        return redirect(referrer)
    else:
        return "이전 페이지가 없습니다."

@app.route('/failed')
def failed():
    return render_template('failed.html')

@app.route('/logout')
def logout():
    if 'user_id' in session:
        user_id = session['user_id']
        user = User.query.get(user_id)
        db.session.commit()
        session.pop('user_id', None)
    return render_template('index.html',comment = '로그아웃 완료')

@app.route('/')
def index():
    if 'user_id' in session:
        user_id = session['user_id']
        user = User.query.filter_by(id = user_id).first()
        if user is not None:
            id = user.id
            name = user.name
        return render_template('index.html', id = id, name = name)
    else:
        return render_template('index.html', id = None)

@app.route('/signup')
def signup():
    return render_template('signup.html')

@app.route('/login')
def login():
    return render_template('login.html')

@app.route('/register', methods=['POST'])
@csrf.exempt
def register():
    if request.method == 'POST':
        id = request.form['ID']
        name = request.form['Name']
        
        # 사용자 이름 중복 검사
        if User.query.filter_by(name=name).first():
            comment1 = '이미 등록된 사용자 이름입니다.'
            return render_template('failed.html', comment=comment1)
        
        age = request.form['Age']
        student_number = request.form['Student_number']
        password = request.form['Password']
        password_hash = generate_password_hash(password)
        level = 2
        new_user = User(id=id, name=name, age=age, student_number=student_number, password_hash=password_hash, level=level)
        db.session.add(new_user)
        db.session.commit()
        comment = '회원가입 완료'
        return render_template('index.html',comment=comment)
    else:
        comment1 = '회원가입 실패'
        return render_template('failed.html', comment=comment1)

@app.route('/login_request', methods=['POST'])
@csrf.exempt
def login_request():
    id_get = request.form['ID']
    password = request.form['Password']
    user = User.query.filter_by(id=id_get).first()
    if user and check_password_hash(user.password_hash, password):
        comment = '로그인 성공'
        db.session.commit()
        session['user_id'] = user.id
        session['user_level'] = user.level
        return render_template('index.html',id = user.id, comment=comment)
    else:
        comment1 = '로그인 실패'
        return render_template('failed.html', comment=comment1)

@app.route('/mypage')
def mypage():
    if 'user_id' not in session:
        flash("로그인이 필요한 기능입니다.", "warning")
        return redirect(url_for('login'))

    user_id = session['user_id']
    user = User.query.get(user_id)
    ai_chat_room = user.ai_chat_room

    if not user:
        flash("사용자 정보를 찾을 수 없습니다.", "danger")
        return redirect(url_for('index'))

    return render_template('mypage.html', user=user, ai_chat_room=ai_chat_room)

@app.route('/create_board', methods=['POST'])
@csrf.exempt
def create_board():
    level = session.get('user_level')
    if request.method == 'POST' and level == 2:
        board_name = request.form['board_name']
        new_board = Board(name=board_name)
        db.session.add(new_board)
        db.session.commit()
        return redirect('/')
    else:
        return render_template('failed.html', comment='게시판 생성 실패')

@app.route('/write_article/<int:board_id>', methods=['GET', 'POST'])
@csrf.exempt
def write_article(board_id):
    if 'user_id' not in session:
        flash('로그인이 필요한 기능입니다.', 'danger')
        return redirect(url_for('login'))
    board = Board.query.get_or_404(board_id)
    if request.method == 'POST':
        title = request.form['title']
        content = request.form['content']
        user_id = session['user_id']
        new_article = Article(title=title, content=content, board_id=board.id, user_id=user_id)
        db.session.add(new_article)
        db.session.commit()
        flash('게시글이 성공적으로 작성되었습니다.', 'success')
        return redirect(url_for('articles', board_id=board_id))
    return render_template('write_article.html', board=board)

@app.route('/articles/<int:board_id>')
def articles(board_id):
    articles = Article.query.filter_by(board_id=board_id).all()
    board = Board.query.get(board_id)
    return render_template('articles.html', articles=articles, board=board)

@app.route('/article/<int:article_id>')
def article(article_id):
    article = Article.query.get(article_id)
    return render_template('article.html', article=article)

@app.route('/attend')
def attend():
    user_id = session.get('user_id') 
    if user_id is None:
        return redirect('/login') 
    user = User.query.filter_by(id=user_id).first()
    if user:
        user_name = user.name

        conn = sqlite3.connect('/Users/rosa/Desktop/prototype_f/dbs/after.db')
        cursor = conn.cursor()
        cursor.execute("SELECT time, id, name, log FROM data WHERE name LIKE ?", ('%' + user_name + '%',))
        logs = cursor.fetchall()
        conn.close()

        return render_template('test.html', logs=logs)
    return redirect('/login')

@app.route('/chat_rooms')
def chat_rooms():
    chat_rooms = ChatRoom.query.all()
    return render_template('chat_rooms.html', chat_rooms=chat_rooms)

@app.route('/chat_room/<int:room_id>')
def chat_room(room_id):
    chat_room = ChatRoom.query.get(room_id)
    chat_messages = ChatMessage.query.filter_by(room_id=room_id).order_by(ChatMessage.timestamp.asc()).all()
    return render_template('chat_room.html', chat_room=chat_room, chat_messages=chat_messages)

@app.route('/create_chat_room', methods=['GET', 'POST'])
@csrf.exempt
def create_chat_room():
    if request.method == 'POST':
        chat_room_name = request.form['chat_room_name']
        new_chat_room = ChatRoom(name=chat_room_name)
        db.session.add(new_chat_room)
        db.session.commit()
        return redirect(url_for('chat_rooms'))
    return render_template('create_chat_room.html')

@csrf.exempt
@app.route('/create_ai_chat_room', methods=['GET', 'POST'])
def create_ai_chat_room():
    if 'user_id' not in session:
        flash('로그인이 필요한 기능입니다.', 'danger')
        return redirect(url_for('login'))

    if request.method == 'POST':
        user_id = session['user_id']
        user = User.query.get(user_id)

        if user.ai_chat_room:
            flash('이미 AI 채팅방이 존재합니다.', 'warning')
        else:
            ai_chat_room = AIChatRoom(user_id=user_id)
            db.session.add(ai_chat_room)
            db.session.commit()
            flash('AI 채팅방이 성공적으로 생성되었습니다.', 'success')

        return redirect(url_for('mypage'))

    return render_template('create_ai_chat_room.html')

@app.route('/ai_chat_rooms')
def ai_chat_rooms():
    if 'user_id' not in session:
        flash('로그인이 필요한 기능입니다.', 'danger')
        return redirect(url_for('login'))

    user_id = session['user_id']
    user = User.query.get(user_id)

    if user.ai_chat_room:
        ai_chat_rooms = [user.ai_chat_room]
    else:
        ai_chat_rooms = []

    return render_template('ai_chat_rooms.html', ai_chat_rooms=ai_chat_rooms)

@app.route('/ai_chat_room/<int:room_id>')
def ai_chat_room(room_id):
    if 'user_id' not in session:
        flash('로그인이 필요한 기능입니다.', 'danger')
        return redirect(url_for('login'))

    chat_room = AIChatRoom.query.get(room_id)
    messages = AIChatMessage.query.filter_by(chat_room_id=room_id).order_by(AIChatMessage.timestamp.asc()).all()
    return render_template('ai_chat_room.html', chat_room=chat_room, messages=messages)

@socketio.on('join')
def handle_join(data):
    room = data['room']
    join_room(room)
    emit('join_response', {'msg': f'{session["user_id"]} has joined the room.'}, room=room)

@socketio.on('leave')
def handle_leave(data):
    room = data['room']
    leave_room(room)
    emit('leave_response', {'msg': f'{session["user_id"]} has left the room.'}, room=room)

@socketio.on('chat message')
def handle_chat_message(data):
    room = data['room']
    message = data['message']
    user_id = session['user_id']
    new_message = ChatMessage(room_id=room, user_id=user_id, message=message)
    db.session.add(new_message)
    db.session.commit()
    emit('chat message', {'user': session["user_id"], 'msg': message}, room=room)

@socketio.on('ai_chat_message')
def handle_ai_chat_message(data):
    message = data['message']
    user_id = session['user_id']
    user = User.query.get(user_id)
    chat_room = user.ai_chat_room

    user_message = AIChatMessage(chat_room_id=chat_room.id, sender='user', message=message)
    db.session.add(user_message)
    db.session.commit()

    prompt = f"User: {message}\nAI:"
    inputs = tokenizer(prompt, return_tensors="pt")

    if 'token_type_ids' in inputs:
        del inputs['token_type_ids']

    output = model.generate(
        **inputs,
        max_new_tokens=50,
        num_return_sequences=1,
        pad_token_id=tokenizer.eos_token_id
    )
    bot_message = tokenizer.decode(output[0], skip_special_tokens=True)

    # Remove the prompt and any duplicate text from the generated response
    bot_message = bot_message.replace(prompt, "").strip()

    # Remove duplicate words or phrases using regex
    bot_message = re.sub(r'\b(\w+\s*)\1+', r'\1', bot_message)

    emit('ai_response', {'message': bot_message}, room=chat_room.id)

    ai_message = AIChatMessage(chat_room_id=chat_room.id, sender='ai', message=bot_message)
    db.session.add(ai_message)
    db.session.commit()
    
if __name__ == '__main__':
    socketio.run(app, debug=True)