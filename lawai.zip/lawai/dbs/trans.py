import os
import time
import pandas as pd
import sqlite3
import logging

def convert_to_sqlite(excel_path, db_path):
    try:
        df = pd.read_excel(excel_path)
        with sqlite3.connect(db_path) as conn:
            df.to_sql(name='data', con=conn, if_exists='replace', index=False)
        logging.info("Excel file converted to SQLite database successfully.")
    except Exception as e:
        logging.error(f"Error occurred: {e}")

def watch_excel_file(excel_path, db_path, interval=5):
    logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')

    last_modified_time = None

    while True:
        try:
            current_modified_time = os.path.getmtime(excel_path)

            if last_modified_time is None or current_modified_time > last_modified_time:
                logging.info(f"Change detected in {excel_path}")
                convert_to_sqlite(excel_path, db_path)
                last_modified_time = current_modified_time

            time.sleep(interval)

        except KeyboardInterrupt:
            logging.info("Stopping the file monitoring.")
            break
        except FileNotFoundError:
            logging.error(f"The file {excel_path} does not exist. Retrying in {interval} seconds.")
            time.sleep(interval)

# 사용 예시
excel_path = '/Users/ROSA/Desktop/prototype_f/dbs/before.xlsx'  # Correct the path as per macOS standards
db_path = '/Users/ROSA/Desktop/prototype_f/dbs/after.db'       # Correct the path as per macOS standards
watch_excel_file(excel_path, db_path)
